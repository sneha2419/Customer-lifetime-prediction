# ETL + CLV Prediction Project

import mysql.connector
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score

conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='AMAN@123',
    database='sampleSales'
)

query = 'SELECT customer_id, order_date, amount FROM transactions;'
df = pd.read_sql(query, conn)
conn.close()

df['order_date'] = pd.to_datetime(df['order_date'])
df = df.dropna()
df = df[df['amount'] > 0]
df = df.drop_duplicates()

reference_date = df['order_date'].max() + pd.Timedelta(days=1)

rfm = df.groupby('customer_id').agg({
    'order_date': [
        lambda x: (reference_date - x.max()).days,
        'count'
    ],
    'amount': 'sum'
})

rfm.columns = ['recency','frequency','monetary']
rfm = rfm.reset_index()

rfm['clv'] = rfm['monetary']

X = rfm[['recency','frequency','monetary']]
y = rfm['clv']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = RandomForestRegressor(n_estimators=300, random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
import numpy as np
rmse = np.sqrt(mean_squared_error(y_test, y_pred))

r2 = r2_score(y_test, y_pred)

print('RMSE:', rmse)
print('R2:', r2)

rfm.to_csv('rfm_features.csv', index=False)
print('Saved rfm_features.csv')
