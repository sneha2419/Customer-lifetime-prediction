
CREATE DATABASE IF NOT EXISTS sampleSales;
USE sampleSales;

-- Customers table
CREATE TABLE IF NOT EXISTS customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(50),
    city VARCHAR(50)
);

INSERT INTO customers (customer_id, customer_name, city) VALUES
(1,'Ali','Lahore'),
(2,'Sara','Karachi'),
(3,'Ahmed','Islamabad'),
(4,'Fatima','Lahore'),
(5,'Usman','Multan');

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    amount DECIMAL(10,2),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

INSERT INTO transactions (transaction_id, customer_id, order_date, amount) VALUES
(101,1,'2024-01-05',1200.00),
(102,1,'2024-02-14',1800.00),
(103,1,'2024-03-02',1600.00),
(104,2,'2024-01-20',900.00),
(105,2,'2024-02-10',1100.00),
(106,3,'2024-01-08',2400.00),
(107,3,'2024-03-21',2600.00),
(108,4,'2024-02-18',700.00),
(109,5,'2024-01-11',1300.00),
(110,5,'2024-02-15',1900.00),
(111,5,'2024-03-18',2100.00);
