FULL PROJECT CONTENTS

1) sampleSales.sql
2) etl_clv_project.py
3) requirements.txt
4) report.md

Run Steps:
- Import sampleSales.sql into MySQL Workbench
- Edit password in etl_clv_project.py
- pip install -r requirements.txt
- python etl_clv_project.py
